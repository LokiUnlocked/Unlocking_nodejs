const { parentPort } = require("node:worker_threads")

parentPort.on("message", ({ taskId }) => {

    let sum = 0
    for (let i = 0; i < 1e10; i++) {
        sum += i
    }
    parentPort.postMessage(`Task id ${taskId} completed`)
})