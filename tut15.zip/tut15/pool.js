const { Worker } = require("node:worker_threads")

function createPool(count, path) {
    const workerPool = []
    const idleWorkers = []
    const taskQueue = []
    let taskId = 0

    for (let i = 0; i < count; i++) {
        const worker = new Worker(path)
        workerPool.push(worker)
        idleWorkers.push(worker)
    }

    function runTask() {
        return new Promise(resolve => {
            taskQueue.push({
                data: { taskId: ++taskId },
                resolve
            })
            runNext()
        })
    }

    function runNext() {
        if (idleWorkers.length === 0 || taskQueue.length === 0) return

        const worker = idleWorkers.shift()
        const task = taskQueue.shift()

        worker.once("message", (msg) => {
            task.resolve(msg)
            idleWorkers.push(worker)
            runNext()
        })

        worker.postMessage(task.data)
    }

    return { runTask }
} 

module.exports = createPool