const createPool = require("./pool.js")
const os = require("node:os")
const count = os.cpus().length

const { runTask } = createPool(count, "./worker.js")

for (let i = 0; i < 8; i++) {
    runTask().then((result) => {

        console.log(result);
        
    })
}
