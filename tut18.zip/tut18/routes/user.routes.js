import express from "express"
import { getUserById, getUsers, createUser } from "../controllers/user.controllers.js"
import { authentication } from "../middleware/authentication.middleware.js"
import { dummyMiddleware } from "../middleware/dummy.middleware.js"
import { getRoleMiddleware } from "../middleware/role.middleware.js"

const router = express.Router()


router.get("/", dummyMiddleware, getRoleMiddleware, authentication, getUsers)

router.get("/:id", authentication, getUserById)

router.post("/", authentication, dummyMiddleware, createUser)

export default router;