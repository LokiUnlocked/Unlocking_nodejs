
const users = [{
    name: "Lokendra",
    id: 1
}, {
    name: "Harshit",
    id: 2
}]

export function getUsers(req, res) {
    console.log("req.id: ", req.id);
    console.log("req.role: ", req.role);
    
    

    res.json({ users })
}

export function getUserById(req, res) {

    const { id, postId } = req.params
    const { name } = req.query
    console.log(req.query)
    const user = users.find(user => user.id === +id)
    res.json(user)
}

export function createUser(req, res) {

    const name = "Umang"
    const id = 3
    users.push({ name, id })
    res.status(201).send("user created successfully")
}