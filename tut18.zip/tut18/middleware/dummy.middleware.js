export function dummyMiddleware(req, res, next) {
    console.log("req in dummy middleware");
    
    next()
}