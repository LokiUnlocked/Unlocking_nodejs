const roles = [
    {
        id: 1,
        role: "ADMIN"
    },
    {
        id: 2,
        role: "USER"
    }
]

export function getRoleMiddleware(req, res, next) {
    try {
        const id = req.id
        const role = roles.find(role => role.id === +id)
        req.role = role
        next()
    } catch (error) {
        console.log("some error occurred");
        return res.status(500).send("some error occurred")

    }
}