// const express = require("express")
import express from "express";
import userRoutes from "./routes/user.routes.js";
import { globalMiddleware } from "./middleware/global.middleware.js";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json())
app.use(globalMiddleware);

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));
});

app.use("/users", userRoutes);

app.listen(3000, () => {
    console.log("server is running on 3000 port");
});
