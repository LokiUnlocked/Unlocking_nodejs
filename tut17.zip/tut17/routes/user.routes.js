import express from "express"
import { getUserById, getUsers, createUser } from "../controllers/user.controllers.js"

const router = express.Router()


router.get("/", getUsers)

router.get("/:id/posts/:postId", getUserById)

router.post("/", createUser)

export default router;