const heavy = require("./heavy-task.js");

process.on("message", ({ start, end }) => {
    const sum = heavy(start, end);
    process.send({
        type: "result",
        sum,
        rss: process.memoryUsage().rss
    })
    process.exit(0)
});