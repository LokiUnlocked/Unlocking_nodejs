const { Worker } = require("worker_threads");
const os = require("os");

const TOTAL = 5_00_00_00000;
const CPU_COUNT = os.cpus().length;
const WORKERS = CPU_COUNT; 

const CHUNK = Math.floor(TOTAL / WORKERS);
// 100 4  --> 25
// start    end
//  0        25
//  25        50
//  50        75
// 75        100
let completed = 0;
let finalSum = 0;

console.log("CPU cores:", CPU_COUNT);

console.time("multi-worker")
for (let i = 0; i < WORKERS; i++) { // 0 --> 7
    const start = i * CHUNK;
    const end = i === WORKERS - 1 ? TOTAL : start + CHUNK;

    const worker = new Worker("./worker.js", {
        workerData: { start, end }
    });

    worker.on("message", (result) => {
        finalSum += result;
        completed++;

        if (completed === WORKERS) {
            console.timeEnd("multi-worker");
            console.log("Final Sum:", finalSum);
        }
    });

    worker.on("error", console.error);
}


console.log(process.memoryUsage().rss / 1024 / 1024, "MB");