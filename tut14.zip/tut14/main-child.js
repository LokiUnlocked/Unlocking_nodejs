const { fork } = require("node:child_process");
const os = require("os");

const TOTAL = 5_00_00_00000;
const CPU_COUNT = os.cpus().length;
const CHILDREN = CPU_COUNT;

const CHUNK = Math.floor(TOTAL / CHILDREN);

let completed = 0;
let finalSum = 0;
let totalMemory = process.memoryUsage().rss;

console.time("multi-child");

for (let i = 0; i < CHILDREN; i++) {
    const start = i * CHUNK;
    const end = i === CHILDREN - 1 ? TOTAL : start + CHUNK;

    const child = fork("./child.js");

    child.send({ start, end });

    child.on("message", (msg) => {
        finalSum += msg.sum;
        totalMemory += msg.rss;
        completed++;

        if (completed === CHILDREN) {
            console.timeEnd("multi-child");

            console.log("Final Sum:", finalSum);
            console.log(
                "Total App Memory:",
                (totalMemory / 1024 / 1024).toFixed(2),
                "MB"
            );
        }
    });

    child.on("error", console.error);
}
