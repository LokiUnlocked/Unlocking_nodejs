function heavy(start, end) {
  console.log(start, end);
  
  let sum = 0;
  for (let i = start; i < end; i++) {
    sum += i;
  }
  return sum;
}

module.exports = heavy;
