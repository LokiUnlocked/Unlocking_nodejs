const { parentPort, workerData } = require("worker_threads");
const heavy = require("./heavy-task.js");

const { start, end } = workerData;

const result = heavy(start, end);

parentPort.postMessage(result);