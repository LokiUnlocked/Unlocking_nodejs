export function globalMiddleware(req, res, next) {
    // console.log("global middleware run");
    next()
    
}