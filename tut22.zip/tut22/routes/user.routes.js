import express from "express"
import { getUserById, getUsers, createUser } from "../controllers/user.controllers.js"
import { authentication } from "../middleware/authentication.middleware.js"
import { dummyMiddleware } from "../middleware/dummy.middleware.js"
import { getRoleMiddleware } from "../middleware/role.middleware.js"

const router = express.Router()


router.get("/", dummyMiddleware,  getUsers)

router.get("/:id",  getUserById)

router.post("/",  createUser)

export default router;