export function authentication(req, res, next) {

    let token = req.headers.authorization
    // console.log(token);

    if (token && token.startsWith("Bearer ")) {
        token = token.replace("Bearer ", "")
    } else {
        return res.status(401).send("please send auth token")
    }

    if(token === "abc") {
        req.id = 1
    } else {
        req.id = 2
    }
    // if (token !== "abc") {
    //     return res.status(401).send("please send auth token")
    // }

    next()
}