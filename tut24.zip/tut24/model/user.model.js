import { Schema, model } from 'mongoose'

const userSchema = new Schema({
    firstName: {
        type: String,
        required: true,
        minLength: 3,
        maxLength: 10
    },
    lastName: {
        type: String,
        required: true
    },
    age: {
        type: Number,
        required: true,
        min: 1,
        max: 100
    },
    role: {
        type: String,
        // required: true,
        enum: ["USER", "ADMIN", "OWNER"],
        default: "USER"
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    }
}, { timestamps: true })

export default model("user", userSchema, "user")