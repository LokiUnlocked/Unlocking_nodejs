import userModel from '../model/user.model.js'

export async function getUsers(req, res) {
    try {
        const users = await userModel.find() // array
        return res.json(users)
    } catch (error) {
        return res.status(500).send("Internal server error")
    }
}

export async function getUserById(req, res) {
    try {
        const { id } = req.params
        // const user = await userModel.findById(id) // object/json
        const user = await userModel.findOne({
            _id: id
        })
        return res.json(user)
    } catch (error) {
        return res.status(500).send("Internal server error")
    }
}

export async function createUser(req, res) {
    try {
        // const { firstName, lastName } = req.body
        // if (!firstName || !lastName) {
        //     return res.status(400).send("first name & last name are required")
        // }

        const user = await userModel.create(req.body)
        return res.status(201).json(user)
    } catch (error) {
        console.log(error);
        
        return res.status(500).send(error.message)
    }
}

export async function updateUser(req, res) {
    try {
        const user = await userModel.findByIdAndUpdate(id, req.body)
        return res.json(user)
    } catch (error) {
        return res.status(500).send("Internal server error")
    }

}


export async function deleteUser(req, res) {
    try {
        const { id } = req.params
        const user = await userModel.findByIdAndDelete(id)
        return res.json(user)
    } catch (error) {
        return res.status(500).send("Internal server error")

    }
}