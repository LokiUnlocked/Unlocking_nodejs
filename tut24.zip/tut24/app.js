import express from "express";
import userRoutes from "./routes/user.routes.js";
import { db } from "./db/db.js";
const app = express();

db()

app.use(express.urlencoded({ extended: true }));
app.use(express.json())

app.use("/users", userRoutes);

app.listen(3000, () => {
    console.log("server is running on 3000 port");
});
