import mongoose from 'mongoose'
import dotenv from 'dotenv'
dotenv.config()

export async function db() {
    try {
        // await mongoose.connect("mongodb://localhost:27017")
        await mongoose.connect(process.env.URI)
        console.log("database connected successfully");
        
    } catch (error) {
        console.log(error)
    }
}