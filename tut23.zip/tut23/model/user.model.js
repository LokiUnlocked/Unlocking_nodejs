import mongoose from 'mongoose'

const userSchema = new mongoose.Schema({
    firstName: {
        type: String
    },
    lastName: {
        type: String
    },
    class: {
        type: Number
    }
})

export default mongoose.model("user", userSchema)