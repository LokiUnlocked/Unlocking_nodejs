import express from 'express'
import { createCompany } from '../controllers/company.controllers.js'

const router = express.Router()

router.post("/", createCompany)

export default router