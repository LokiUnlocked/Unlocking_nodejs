import postModel from '../model/post.model.js'

export async function createPost(req, res) {
    try {
        const { user, title, content } = req.body
        const data = await postModel.create({ content, title, user })
        return res.status(201).json(data)
    } catch (error) {
        return res.status(404).send(error.message || "Some error occurred")
    }
}

export async function getPosts(req, res) {
    try {
        // const posts = await postModel.find().populate("user", "firstName lastName company -_id")
        const posts = await postModel.find().populate({
            path: "user",
            populate: {
                path: "company"
            }
        })
        return res.json(posts)
    } catch (error) {
        return res.status(404).send(error.message || "Some error occurred")
    }
}