import companyModel from "../model/company.model.js"

export async function createCompany(req, res) {
    try {
        const { name } = req.body
        const company = await companyModel.create({ name })
        return res.status(201).json(company)
    } catch (error) {
        return res.status(404).send(error.message)
    }
}