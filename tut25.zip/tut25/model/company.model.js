import { Schema, model } from 'mongoose'

const companySchema = new Schema({
    name: {
        type: String,
        required: true
    }
})

export default model("company", companySchema)