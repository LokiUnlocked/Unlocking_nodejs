// const express = require("express")
import express from "express"

const app = express()

app.use((req, res, next) => {
    console.log("request received");
    // next()
    res
        .status(201)
        .json({ name: "Loki Unlocked", message: "Hello from app.use" })
})

app.get("/", (req, res) => {
    // res.send("Hello world!")
    res
        .status(201)
        .json({ name: "Loki Unlocked", message: "Hello from Lokendra" })
})

app.listen(3000, () => {
    console.log("server is running on 3000 port");
})